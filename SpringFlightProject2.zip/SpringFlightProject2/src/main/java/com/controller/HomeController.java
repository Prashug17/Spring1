package com.controller;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dao.FlightDaoImpl;
import com.dao.JavaConfigurationClass;
import com.model.BookingDetails;
import com.model.Customer;
import com.model.Flight;



@Controller
@RequestMapping("/flight")
public class HomeController {

	static int flid;
	static float fltp;
	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigurationClass.class);
	static FlightDaoImpl pDao=context.getBean("pDao", FlightDaoImpl.class);
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}
	
	@RequestMapping("/adminhome")
	public String adminHome() {
		return "adminhome";
	}
	
	@RequestMapping("/customerhome")
	public String customerHome() {
		return "customerhome";
	}
	
	@RequestMapping("/addflight")
	public String addFlight() {
		return "addflight";
	}
	
	@RequestMapping("/addedsuccess")
	public String addStudentInDb(@ModelAttribute Flight flight) {
		Flight flt = new Flight();
		flt.setFlight_id(flight.getFlight_id());
		flt.setFlight_name(flight.getFlight_name());
		flt.setFlight_date(flight.getFlight_date());
		flt.setFlight_source(flight.getFlight_source());
		flt.setFlight_destination(flight.getFlight_destination());
		flt.setFlight_price(flight.getFlight_price());
		flt.setFlight_duration(flight.getFlight_duration());
		flt.setFlight_capacity(flight.getFlight_capacity());
		
		pDao.insertFlight(flt);
		return "addedsuccess";

	}
	
	@RequestMapping("/updateflight")
	public String updateFlight() {
		return "updateflight";
	}
	
	@RequestMapping("/updatesuccess")
	public String updateflt(@ModelAttribute Flight flight) {
		
		pDao.updateFlight(flight);
		return "updatesuccess";
	}
	
	@RequestMapping("/deleteflight")
	public String deleteFlight() {
		return "deleteflight";

	}

	@RequestMapping("/deletesuccess")
	public String deleteFlt(@RequestParam("flight_id") int id) {

		Flight flt=new Flight();
		flt.setFlight_id(id);
		pDao.deleteFlight(flt);
		return "deletesuccess";
	}
	
	@RequestMapping("/getAllFlights")
	public ModelAndView getFlights(ModelAndView mv) {
		List<Flight> flights =pDao.getAllFlights();
		mv.addObject("flights1",flights);
		mv.setViewName("getAllFlights");
		return mv;
	}
	
	@RequestMapping("/addcustomer")
	public String addcustomer() {
		return "addcustomer";
	}
	
	@RequestMapping("/customeraddedsuccess")
	public String addCustomer(@ModelAttribute Customer customer) {
		Customer cust = new Customer();
		cust.setCustomer_id(customer.getCustomer_id());
		cust.setCustomer_name(customer.getCustomer_name());
		cust.setCustomer_username(customer.getCustomer_username());
		cust.setCustomer_password(customer.getCustomer_password());
		cust.setCustomer_email(customer.getCustomer_email());
		cust.setCustom_phone(customer.getCustom_phone());
		
		pDao.addCustomer(cust);
		return "customeraddedsuccess";
	}
	
	@RequestMapping("/updatecustomer")
	public String updateCustomer() {
		return "updatecustomer";
	}
	
	@RequestMapping("/customerupdatesuccess")
	public String updateCustomer(@ModelAttribute Customer customer) {
		
		pDao.updateCustomer(customer);
		return "customerupdatesuccess";
	}
	
	@RequestMapping("/deleteaccount")
	public String deleteaccount() {
		return "deleteaccount";
	}
	
	@RequestMapping("/deletecustsuccess")
	public String deleteFromDatabase(@RequestParam("customer_id") int id) {
		pDao.deleteCustomer(id);
		return "deletecustsuccess";
	}
	
	@RequestMapping("/bookticket")
	public String bookticket() {
		
		return "bookticket";
	}
	
	@RequestMapping("/bookingaddedsuccess")
	public String bookingTicket(@RequestParam("flight_date") String date,@RequestParam("flight_source") String source,@RequestParam("flight_destination") String destination,@RequestParam("customer_id") int cid,@RequestParam("seat_number") int seat ) {
		List<Flight> flight= pDao.bookFlight(date,source,destination);
		Iterator<Flight> itr=flight.iterator();
		while(itr.hasNext()) {
			Flight flt=itr.next();
			flid=flt.getFlight_id();
			fltp=flt.getFlight_price();
		}
		
		pDao.bookingFlight( cid,flid,fltp,seat);
		return "bookingaddedsuccess";
	}
	
	@RequestMapping("/updatebooking")
	public String updateBooking() {
		return "updatebooking";
	}
	
	@RequestMapping("/updatebookingsuccess")
	public String updateBooking(@ModelAttribute Flight flight) {
		
		pDao.updateBooking(flight);
		return "updatebookingsuccess";
	}
	
	@RequestMapping("/cancelticket")
	public String cancelticket() {
		return "cancelticket";

	}

	@RequestMapping("/cancelsuccess")
	public String cancelTicket(@RequestParam("booking_id") int id) {
		pDao.cancelBooking(id);
		return "cancelsuccess";
	}
	
	@RequestMapping("/getticketdetails")
	public String getticketdetails() {
		return "getticketdetails";
	}
	
	@RequestMapping("/ticketdetails")
	public String displaydetails(@RequestParam("booking_id") int id, Model model) {
		List<BookingDetails> book = pDao.getBookingDetails(id);
		model.addAttribute("book",book);
		return "ticketdetails";		
	}
}

