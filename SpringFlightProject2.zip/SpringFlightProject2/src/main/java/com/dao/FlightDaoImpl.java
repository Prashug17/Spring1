package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.model.BookingDetails;
import com.model.Customer;
import com.model.Flight;

public class FlightDaoImpl implements FlightDao {

	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertFlight(Flight flight) {
		String query = "insert into flight values (?,?,?,?,?,?,?,?)";
		int row=this.jdbcTemplate.update(query,flight.getFlight_id(),flight.getFlight_name(),flight.getFlight_date(),flight.getFlight_source(),flight.getFlight_destination(),flight.getFlight_price(),flight.getFlight_duration(),flight.getFlight_capacity());
		return row;
	}

	public int updateFlight(Flight flight) {
		String query = "update flight set flight_name=?,flight_date=?,flight_source=?,flight_destination=?,flight_price=?,flight_duration=?,flight_capacity=? where flight_id=?";
		int row=this.jdbcTemplate.update(query,flight.getFlight_name(),flight.getFlight_date(),flight.getFlight_source(),flight.getFlight_destination(),flight.getFlight_price(),flight.getFlight_duration(),flight.getFlight_capacity(),flight.getFlight_id());
		return row;
	}

	public int deleteFlight(Flight flight) {
		String query = "delete from flight where flight_id=?";
        int row = this.jdbcTemplate.update(query,flight.getFlight_id());
        return row;
	}


	public List<Flight> getAllFlights() {
		String query = "select * from flight";
		RowMapper<Flight> rowMapper = new RowMapperFlightImpl();
		List<Flight> flt =this.jdbcTemplate.query(query,rowMapper);
		return flt;
	}

	public int addCustomer(Customer customer) {
		String query = "insert into customer values (?,?,?,?,?,?)";
		int row=this.jdbcTemplate.update(query,customer.getCustomer_id(),customer.getCustomer_name(),customer.getCustomer_username(),customer.getCustomer_password(),customer.getCustomer_email(),customer.getCustom_phone());
		return row;
	}

	public int updateCustomer(Customer customer) {
		String query = "update customer set customer_name=?,customer_username=?,customer_password=?,customer_email=?,custom_phone=? where customer_id=?";
		int row=this.jdbcTemplate.update(query,customer.getCustomer_name(),customer.getCustomer_username(),customer.getCustomer_password(),customer.getCustomer_email(),customer.getCustom_phone(),customer.getCustomer_id());
		return row;
	}

	public int deleteCustomer(int id) {
		String query = "delete from customer where customer_id=?";
        int row = this.jdbcTemplate.update(query,id);
        return row;
	}

	public  List<Flight> bookFlight(String date,String source,String destination) {
		String query = "select * from flight where flight_date=? AND flight_source=? AND flight_destination=?";
		RowMapper<Flight> rowMapper = new RowMapperFlightImpl();
		List<Flight> flt = this.jdbcTemplate.query(query,rowMapper,date,source,destination);
		return  flt;
	}

	public int bookingFlight(int custid,int fltid,float price,int seatno) {
		String query = "insert into booking (customer_id,flight_id,booking_amount,seat_number) values (?,?,?,?)";
		int row=this.jdbcTemplate.update(query,custid,fltid,price,seatno);
		return row;
	}
	
	public int updateBooking(Flight flight) {
		String query = "update flight set flight_date=? where flight_id=?";
		int row=this.jdbcTemplate.update(query,flight.getFlight_date(),flight.getFlight_id());
		return row;
	}

	public int cancelBooking(int id) {
		String query = "delete from booking where booking_id=?";
        int row = this.jdbcTemplate.update(query,id);
        return row;
	}

	public List<BookingDetails> getBookingDetails(int id) {
		String query = "select * from booking where booking_id=? ";
		RowMapper<BookingDetails> rowMapper = new RowMapperBookingImpl();
		List<BookingDetails> book =this.jdbcTemplate.query(query,rowMapper,id);
		return book;
	}

}