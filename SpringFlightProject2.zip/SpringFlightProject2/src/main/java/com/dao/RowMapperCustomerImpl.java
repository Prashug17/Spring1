package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Customer;



public class RowMapperCustomerImpl implements RowMapper<Customer> {

	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Customer cust = new Customer();
		cust.setCustomer_id(rs.getInt(1));
		cust.setCustomer_name(rs.getString(2));
		cust.setCustomer_username(rs.getString(3));
		cust.setCustomer_password(rs.getString(4));
		cust.setCustomer_email(rs.getString(5));
		cust.setCustom_phone(rs.getString(6));
		return cust;
		
	}


}