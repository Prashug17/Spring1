package com.dao;

import java.util.List;

import com.model.BookingDetails;
import com.model.Customer;
import com.model.Flight;

public interface FlightDao {
	public int insertFlight(Flight flight);
	public int updateFlight(Flight flight);
	public int deleteFlight(Flight flight);
	public List<Flight> getAllFlights();
	
	public int addCustomer(Customer customer);
	public int updateCustomer(Customer customer);
	public int deleteCustomer(int id);
	public List<Flight> bookFlight(String date,String source,String destination);
	public int bookingFlight(int custid,int fltid,float price,int seatno);
	public int updateBooking(Flight flight);
	public int cancelBooking(int id);
	public List<BookingDetails> getBookingDetails(int id);
	
	
}