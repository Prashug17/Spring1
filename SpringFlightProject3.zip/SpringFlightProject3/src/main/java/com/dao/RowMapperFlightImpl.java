package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Flight;


public class RowMapperFlightImpl implements RowMapper<Flight> {

	public Flight mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Flight flt = new Flight();
		flt.setFlight_id(rs.getInt(1));
		flt.setFlight_name(rs.getString(2));
		flt.setFlight_date(rs.getString(3));
		flt.setFlight_source(rs.getString(4));
		flt.setFlight_destination(rs.getString(5));
		flt.setFlight_price(rs.getFloat(6));
		flt.setFlight_duration(rs.getFloat(7));
		flt.setFlight_capacity(rs.getInt(8));
		return flt;
		
	}


}