package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.BookingDetails;


public class RowMapperBookingImpl implements RowMapper<BookingDetails> {

	public BookingDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BookingDetails book = new BookingDetails();
		book.setBooking_id(rs.getInt(1));
		book.setCustomer_id(rs.getInt(2));
		book.setFlight_id(rs.getInt(3));
		book.setBooking_amount(rs.getFloat(4));
		book.setSeat_number(rs.getInt(5));
		return book;
		
	}


}