package com.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class Customer {
	
	@NotNull(message = "Id can't be empty")
	private int customer_id;
	
	@NotNull(message = "Name can't be empty")
	private String customer_name;
	
	@NotNull(message = "User name can't be empty")
	private String customer_username;
	
	@NotNull(message = "Password can't be empty")
	private String customer_password;
	
	@NotNull(message = "Email can't be empty")
	private String customer_email;
	
	@Min(value = 10,message = "Phone number can't be less than 10 digits")
	@Max(value = 10,message = "Phone number can't be more than 10 digits")
	private String custom_phone;
	
	public Customer() {
		super();
	}
	
	public Customer(int customer_id, String customer_name, String customer_username, String customer_password,
			String customer_email, String custom_phone) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.customer_username = customer_username;
		this.customer_password = customer_password;
		this.customer_email = customer_email;
		this.custom_phone = custom_phone;
	}



	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getCustomer_username() {
		return customer_username;
	}

	public void setCustomer_username(String customer_username) {
		this.customer_username = customer_username;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustom_phone() {
		return custom_phone;
	}

	public void setCustom_phone(String custom_phone) {
		this.custom_phone = custom_phone;
	}

	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_name=" + customer_name + ", customer_username="
				+ customer_username + ", customer_password=" + customer_password + ", customer_email=" + customer_email
				+ ", custom_phone=" + custom_phone + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((custom_phone == null) ? 0 : custom_phone.hashCode());
		result = prime * result + ((customer_email == null) ? 0 : customer_email.hashCode());
		result = prime * result + customer_id;
		result = prime * result + ((customer_name == null) ? 0 : customer_name.hashCode());
		result = prime * result + ((customer_password == null) ? 0 : customer_password.hashCode());
		result = prime * result + ((customer_username == null) ? 0 : customer_username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (custom_phone == null) {
			if (other.custom_phone != null)
				return false;
		} else if (!custom_phone.equals(other.custom_phone))
			return false;
		if (customer_email == null) {
			if (other.customer_email != null)
				return false;
		} else if (!customer_email.equals(other.customer_email))
			return false;
		if (customer_id != other.customer_id)
			return false;
		if (customer_name == null) {
			if (other.customer_name != null)
				return false;
		} else if (!customer_name.equals(other.customer_name))
			return false;
		if (customer_password == null) {
			if (other.customer_password != null)
				return false;
		} else if (!customer_password.equals(other.customer_password))
			return false;
		if (customer_username == null) {
			if (other.customer_username != null)
				return false;
		} else if (!customer_username.equals(other.customer_username))
			return false;
		return true;
	}
	
	
}

