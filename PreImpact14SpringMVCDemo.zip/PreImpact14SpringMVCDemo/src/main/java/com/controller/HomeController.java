package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/app")
public class HomeController {

	// handler methods 
	@RequestMapping("/message")
	@ResponseBody
	public String getMessage() {
		System.out.println("I am working");
		return "Good Afternoon";
	}
	
//	@RequestMapping("/home1")
//	public String getHome(Model model) {
//		System.out.println("getHome Method Called");
//		model.addAttribute("student","John");
//		model.addAttribute("id","102");
//		List<String> cities = new ArrayList();
//		cities.add("Mumbai");
//		cities.add("Delhi");
//		cities.add("Chennai");
//		model.addAttribute("cities",cities);		
//		return "home";
//	}
//	
//	@RequestMapping("/course")
//	public ModelAndView courses() {
//		ModelAndView mv = new ModelAndView();
//		mv.addObject("dept","IT");
//		List<String> courses = new ArrayList();
//		courses.add("C#");
//		courses.add("Java");
//		courses.add("HTMl");
//		mv.addObject("crs", courses);
//		mv.setViewName("courses");
//		return mv;
//	}
	
//	@RequestMapping("/home")
//		public String getHomePage(Model model) {
//			String name="Bhushan";
//			model.addAttribute("ename",name);
//			//model.addAllAttributes(null);
//			List<String> list=new ArrayList<String>();
//			list.add("sanjay");
//			list.add("dev");
//			model.addAttribute("listOfFriends",list);
//			return "home";
//			}
	
	@RequestMapping("/home")
    public ModelAndView getContactUS(ModelAndView mv1) {
        ModelAndView mv=new ModelAndView();
        mv.addObject("course","AWS");
        mv.setViewName("contactus");
        return mv;


    }
}
	
	


	

