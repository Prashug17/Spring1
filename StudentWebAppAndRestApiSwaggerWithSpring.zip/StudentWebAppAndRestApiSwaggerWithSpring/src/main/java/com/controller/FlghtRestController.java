package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.FlightRepository;
import com.model.Flight;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class FlghtRestController {
	
	@Autowired
	FlightRepository studRepo;
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String,String> handleInvalidArguments(MethodArgumentNotValidException ex){
		Map<String,String> errorMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error->{
			errorMap.put(error.getField(), error.getDefaultMessage());
		});
		return errorMap;
	}
	
	
//	Get All Students
	@GetMapping("/student")
	public List<Flight> getStudents(){
	 List<Flight> list=(List<Flight>) studRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
	
//	Get All Students
//	Using Response Entity Example
	@GetMapping("/studentres")
	public ResponseEntity<List<Flight>>  getStudentsWithResponseEntity(){
	 List<Flight> list=(List<Flight>) studRepo.findAll();
	 System.out.println(list);
	 return new ResponseEntity<List<Flight>>(list, HttpStatus.OK);
	}
	
//	Get student by id
	@GetMapping("/student/{sid}")
	public Flight getStudentById(@PathVariable("sid") int sid) {
		Flight st = new Flight();
		Optional<Flight> std =studRepo.findById(sid);
		st = std.get();
		return st;		
	}
//	add/insert student
	@PostMapping("/student")
	@PreAuthorize("hasRole('ADMIN')")
	public Flight addStudent(@RequestBody @Valid Flight student) {
		Flight st = new Flight();
		st.setSname(student.getSname());
		st.setSaddress(student.getSaddress());
		st.setSage(student.getSage());
		st.setPhone(student.getPhone());
		studRepo.save(st);
		return st;
	}
//	update student
	@PutMapping("/student/{sid}")
	public Flight updateStudent(@RequestBody Flight student, @PathVariable("sid") int sid) {
		Flight st = new Flight();
		Optional<Flight> std =studRepo.findById(sid);
		st = std.get();
		st.setSname(student.getSname());
		st.setSaddress(student.getSaddress());
		st.setSage(student.getSage());
		st.setPhone(student.getPhone());
		studRepo.save(st);
		return st;		
	}
	
//	delete student by ID
	@DeleteMapping("/student/{sid}")
	public Flight deleteStudentById(@PathVariable("sid") int sid) {
		Flight st = new Flight();
		st= studRepo.findById(sid).get();
		studRepo.deleteById(sid);
		return st;		
	}
		
}
