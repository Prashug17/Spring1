package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="Flight")
public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fid;
	@NotNull(message = "Name can't be null")
	private String fname;
	@NotBlank(message = "Can't be blank")
	private String forigin;
	@NotBlank(message = "Can't be blank")
	private String fdeparture;
	@NotNull(message = "Name can't be null")
	private String dateofdeparture;
	@NotNull(message = "Name can't be null")
	private String dateofarrival;
	private int priceeco;
	private int pricebus;
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getForigin() {
		return forigin;
	}
	public void setForigin(String forigin) {
		this.forigin = forigin;
	}
	public String getFdeparture() {
		return fdeparture;
	}
	public void setFdeparture(String fdeparture) {
		this.fdeparture = fdeparture;
	}
	public String getDateofdeparture() {
		return dateofdeparture;
	}
	public void setDateofdeparture(String dateofdeparture) {
		this.dateofdeparture = dateofdeparture;
	}
	public String getDateofarrival() {
		return dateofarrival;
	}
	public void setDateofarrival(String dateofarrival) {
		this.dateofarrival = dateofarrival;
	}
	public int getPriceeco() {
		return priceeco;
	}
	public void setPriceeco(int priceeco) {
		this.priceeco = priceeco;
	}
	public int getPricebus() {
		return pricebus;
	}
	public void setPricebus(int pricebus) {
		this.pricebus = pricebus;
	}
	@Override
	public String toString() {
		return "Flight [fid=" + fid + ", fname=" + fname + ", forigin=" + forigin + ", fdeparture=" + fdeparture
				+ ", dateofdeparture=" + dateofdeparture + ", dateofarrival=" + dateofarrival + ", priceeco=" + priceeco
				+ ", pricebus=" + pricebus + "]";
	}
	
	

}
