package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


import com.model.Product;

public class ProductDaoImpl implements ProductDao {

	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertProduct(Product product) {
		String query = "insert into product values (?,?,?)";
		int row=this.jdbcTemplate.update(query,product.getPid(),product.getPname(),product.getPprice());
		return row;
	}

	public int updateProduct(Product product) {
		String query = "update product set pname=? where pid=?";
		int row=this.jdbcTemplate.update(query,product.getPname(),product.getPid());
		return row;
	}

	public int deleteProduct(Product product) {
		String query = "delete from Product where pid=?";
        int row = this.jdbcTemplate.update(query,product.getPid());
        return row;
	}

	public Product getProduct(int pid) {
		String query="select * from product where pid= ?";
		RowMapper<Product> rowMapper = new RowMapperImpl();
		Product product =this.jdbcTemplate.queryForObject(query, rowMapper,pid);
		return product;
	}

	public List<Product> getAllProduct() {
		String query = "select * from product";
		List<Product> prod =this.jdbcTemplate.query(query, new RowMapperImpl());
		return prod;
	}

}