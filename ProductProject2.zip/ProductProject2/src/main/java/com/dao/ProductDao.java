package com.dao;

import java.util.List;

import com.model.Product;


public interface ProductDao {
	public int insertProduct(Product product);
}