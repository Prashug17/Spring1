package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.model.Product;

public class RowMapperImpl implements RowMapper<Product> {

	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Product prod = new Product();
		prod.setProduct_id(rs.getInt(1));
		prod.setProduct_name(rs.getString(2));
		prod.setProduct_price(rs.getInt(3));
		prod.setProduct_brand(rs.getString(4));
		prod.setProduct_expirydate(rs.getString(5));
		return prod;
		
	}


}