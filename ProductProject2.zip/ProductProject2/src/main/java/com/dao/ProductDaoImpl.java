package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


import com.model.Product;

public class ProductDaoImpl implements ProductDao {

	
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertProduct(Product product) {
		String query = "insert into product values (?,?,?,?,?)";
		int row=this.jdbcTemplate.update(query,product.getProduct_id(),product.getProduct_name(),product.getProduct_price(),product.getProduct_brand(),product.getProduct_expirydate());
		return row;
	}


}