package com.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.dao.JavaConfigurationClass;
import com.dao.ProductDaoImpl;
import com.model.Product;


@Controller
public class HomeController {
	
	
	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigurationClass.class);
	static ProductDaoImpl pDao=context.getBean("pDao", ProductDaoImpl.class);
	
	
	
	@RequestMapping("/home")
	public String getHomePage() {
		
		return "home";
		
	}
	
	@RequestMapping("/addProduct")
	public String addProduct() {
		return "addProduct";
	}
	
	@RequestMapping("/added")
	public String insertProduct(@RequestParam("product_id") int pid,@RequestParam("product_name") String pname, @RequestParam("product_price")int pprice,@RequestParam("product_brand") String pbrand, @RequestParam("product_expirydate")String pdate) {
		Product prod = new Product();
		prod.setProduct_id(pid);
		prod.setProduct_name(pname);
		prod.setProduct_price(pprice);
		prod.setProduct_brand(pbrand);
		prod.setProduct_expirydate(pdate);
		
		 int i= pDao.insertProduct(prod);
		 System.out.println(i + "Rows Effected");
		
		return "addMessage";
	}
	
}

