package com.view;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.EmpDao;
import com.model.Emp;

public class mainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");

		EmpDao empDao = context.getBean("empDao", EmpDao.class);
//		// insert
//     Emp emp = new Emp();
//     emp.setEmp_id(4);
//     emp.setEmp_name("Raj");
//     int result = empDao.insertEmployee(emp);
//     System.out.println(result+"Employee Inserted");
		
		
		// update
     Emp emp1= new Emp();
     emp1.setEmp_id(2);
     emp1.setEmp_name("Tarun");
     int result1=empDao.updateEmployee(emp1);
     System.out.println(result1+"Employee Updated");
		
		
//		// delete
//		Emp emp2 = new Emp();
//		emp2.setEmp_id(3);
//		int result3 = empDao.deleteEmployee(emp2);
//		System.out.println(result3 + "Emloyee Deleted");
		
		
//		//Display one employee
//		Emp emp3 = empDao.getEmp(1);
//		System.out.println(emp3.getEmp_id()+"-"+emp3.getEmp_name());
	
		//Display all Employee
		List<Emp> emp4=empDao.getAllEmployees();
		for(Emp e:emp4) {
			System.out.println(e.getEmp_id()+"-"+e.getEmp_name());
		}
		
	}
}